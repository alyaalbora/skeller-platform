import React, { useState } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import Navbar from '../components/Navbar';
import RegisterForm from '../components/RegisterForm';

const Register = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();

  const handleRegister = async (userData) => {
    try {
      setLoading(true);
      setError('');
      
      // This would be replaced with actual API call in production
      console.log('Register data:', userData);
      
      // Simulate successful registration
      setTimeout(() => {
        // Redirect to login page after successful registration
        router.push('/login');
      }, 1000);
    } catch (err) {
      setError(err.message || 'حدث خطأ أثناء إنشاء الحساب');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <Head>
        <title>إنشاء حساب جديد - منصة سكيلر التعليمية</title>
        <meta name="description" content="إنشاء حساب جديد في منصة سكيلر التعليمية" />
      </Head>

      <Navbar />
      
      <main className="container main-content">
        <div className="auth-container">
          <RegisterForm onRegister={handleRegister} />
        </div>
      </main>
      
      <footer className="footer">
        <div className="container">
          <p>جميع الحقوق محفوظة &copy; منصة سكيلر {new Date().getFullYear()}</p>
        </div>
      </footer>
    </div>
  );
};

export default Register;
