import React from 'react';
import Head from 'next/head';
import Navbar from '../components/Navbar';
import CourseCard from '../components/CourseCard';

const Home = ({ courses = [] }) => {
  return (
    <div>
      <Head>
        <title>سكيلر - منصة الكورسات التعليمية</title>
        <meta name="description" content="منصة سكيلر التعليمية لإدارة الكورسات والفيديوهات" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <Navbar />
      
      <main className="container main-content">
        <section className="hero-section">
          <div className="hero-content">
            <h1 className="hero-title">تعلم مهارات جديدة مع منصة سكيلر</h1>
            <p className="hero-description">
              منصة تعليمية متكاملة تقدم كورسات في مختلف المجالات بجودة عالية
            </p>
            <button className="btn btn-primary hero-button">استكشف الكورسات</button>
          </div>
        </section>
        
        <section className="featured-courses">
          <h2 className="section-title">الكورسات المميزة</h2>
          <div className="courses-grid">
            {courses.length > 0 ? (
              courses.map((course) => (
                <CourseCard key={course._id} course={course} />
              ))
            ) : (
              <p className="no-courses">لا توجد كورسات متاحة حالياً</p>
            )}
          </div>
        </section>
        
        <section className="platform-features">
          <h2 className="section-title">مميزات المنصة</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">📹</div>
              <h3 className="feature-title">فيديوهات عالية الجودة</h3>
              <p className="feature-description">
                استمتع بمشاهدة فيديوهات تعليمية بجودة عالية تصل مدتها إلى ساعة كاملة
              </p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">🔍</div>
              <h3 className="feature-title">سهولة البحث والتصفح</h3>
              <p className="feature-description">
                يمكنك البحث عن الكورسات والفيديوهات بسهولة وتصفحها حسب التصنيف
              </p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">📱</div>
              <h3 className="feature-title">متوافق مع جميع الأجهزة</h3>
              <p className="feature-description">
                يمكنك الوصول إلى المنصة من أي جهاز سواء كمبيوتر أو هاتف ذكي أو تابلت
              </p>
            </div>
          </div>
        </section>
      </main>
      
      <footer className="footer">
        <div className="container">
          <p>جميع الحقوق محفوظة &copy; منصة سكيلر {new Date().getFullYear()}</p>
        </div>
      </footer>
    </div>
  );
};

export default Home;
