import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import Navbar from '../../components/Navbar';
import VideoPlayer from '../../components/VideoPlayer';

const CourseDetails = ({ initialCourse = null }) => {
  const [course, setCourse] = useState(initialCourse);
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const { id } = router.query;

  // This would be replaced with actual API call in production
  useEffect(() => {
    if (id) {
      // Simulate course data
      const mockCourse = {
        _id: id,
        title: 'عنوان الكورس التجريبي',
        description: 'وصف تفصيلي للكورس يشرح محتواه وأهدافه والفئة المستهدفة منه',
        instructor: 'اسم المدرب',
        category: 'البرمجة',
        duration: 180, // 3 hours in minutes
        views: 1250,
        thumbnail: '/images/default-course.jpg',
        videos: [
          {
            _id: 'v1',
            title: 'مقدمة الكورس',
            description: 'مقدمة تعريفية عن الكورس ومحتواه',
            duration: 600, // 10 minutes in seconds
            thumbnail: '/images/default-video.jpg',
            filePath: 'https://example.com/video1.mp4'
          },
          {
            _id: 'v2',
            title: 'الدرس الأول',
            description: 'شرح الدرس الأول من الكورس',
            duration: 1200, // 20 minutes in seconds
            thumbnail: '/images/default-video.jpg',
            filePath: 'https://example.com/video2.mp4'
          }
        ]
      };
      
      setCourse(mockCourse);
      if (mockCourse.videos && mockCourse.videos.length > 0) {
        setSelectedVideo(mockCourse.videos[0]);
      }
      setLoading(false);
    }
  }, [id]);

  const handleVideoSelect = (video) => {
    setSelectedVideo(video);
    // In production, this would track video view via API
  };

  if (loading) {
    return (
      <div>
        <Navbar />
        <div className="container">
          <div className="loading">جاري تحميل الكورس...</div>
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div>
        <Navbar />
        <div className="container">
          <div className="not-found">الكورس غير موجود</div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Head>
        <title>{course.title} - منصة سكيلر التعليمية</title>
        <meta name="description" content={course.description} />
      </Head>

      <Navbar />
      
      <main className="container main-content">
        <div className="course-details-container">
          <div className="course-header">
            <h1 className="course-title">{course.title}</h1>
            <div className="course-meta">
              <span className="course-instructor">المدرب: {course.instructor}</span>
              <span className="course-category">التصنيف: {course.category}</span>
              <span className="course-duration">المدة: {Math.floor(course.duration / 60)} ساعة {course.duration % 60} دقيقة</span>
              <span className="course-views">المشاهدات: {course.views}</span>
            </div>
          </div>
          
          <div className="course-content">
            <div className="video-section">
              {selectedVideo ? (
                <VideoPlayer video={selectedVideo} />
              ) : (
                <div className="no-video">
                  <p>يرجى اختيار فيديو للمشاهدة</p>
                </div>
              )}
            </div>
            
            <div className="course-sidebar">
              <div className="course-description">
                <h3>وصف الكورس</h3>
                <p>{course.description}</p>
              </div>
              
              <div className="videos-list">
                <h3>محتويات الكورس</h3>
                <ul>
                  {course.videos.map((video) => (
                    <li 
                      key={video._id} 
                      className={selectedVideo && selectedVideo._id === video._id ? 'active' : ''}
                      onClick={() => handleVideoSelect(video)}
                    >
                      <div className="video-item">
                        <div className="video-thumbnail">
                          <img src={video.thumbnail} alt={video.title} />
                        </div>
                        <div className="video-info">
                          <h4 className="video-title">{video.title}</h4>
                          <span className="video-duration">
                            {Math.floor(video.duration / 60)}:{String(video.duration % 60).padStart(2, '0')}
                          </span>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <footer className="footer">
        <div className="container">
          <p>جميع الحقوق محفوظة &copy; منصة سكيلر {new Date().getFullYear()}</p>
        </div>
      </footer>
    </div>
  );
};

export default CourseDetails;
