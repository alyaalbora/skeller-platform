import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import Navbar from '../../components/Navbar';
import CourseCard from '../../components/CourseCard';

const Courses = ({ initialCourses = [] }) => {
  const [courses, setCourses] = useState(initialCourses);
  const [loading, setLoading] = useState(false);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const router = useRouter();

  // This would be replaced with actual API call in production
  useEffect(() => {
    // Simulate categories
    setCategories(['البرمجة', 'التصميم', 'التسويق', 'اللغات', 'الأعمال']);
  }, []);

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    // In production, this would filter courses by category from API
  };

  return (
    <div>
      <Head>
        <title>الكورسات - منصة سكيلر التعليمية</title>
        <meta name="description" content="استعرض جميع الكورسات المتاحة على منصة سكيلر التعليمية" />
      </Head>

      <Navbar />
      
      <main className="container main-content">
        <section className="courses-header">
          <h1 className="page-title">الكورسات المتاحة</h1>
          <p className="page-description">
            استعرض جميع الكورسات المتاحة على المنصة واختر ما يناسبك
          </p>
        </section>
        
        <section className="courses-filters">
          <div className="filter-container">
            <div className="category-filter">
              <h3>التصنيفات</h3>
              <ul className="category-list">
                <li 
                  className={selectedCategory === 'all' ? 'active' : ''}
                  onClick={() => handleCategoryChange('all')}
                >
                  جميع التصنيفات
                </li>
                {categories.map((category) => (
                  <li 
                    key={category}
                    className={selectedCategory === category ? 'active' : ''}
                    onClick={() => handleCategoryChange(category)}
                  >
                    {category}
                  </li>
                ))}
              </ul>
            </div>
          </div>
          
          <div className="courses-container">
            {loading ? (
              <div className="loading">جاري تحميل الكورسات...</div>
            ) : courses.length > 0 ? (
              <div className="courses-grid">
                {courses.map((course) => (
                  <CourseCard key={course._id} course={course} />
                ))}
              </div>
            ) : (
              <div className="no-courses">
                <p>لا توجد كورسات متاحة في هذا التصنيف</p>
              </div>
            )}
          </div>
        </section>
      </main>
      
      <footer className="footer">
        <div className="container">
          <p>جميع الحقوق محفوظة &copy; منصة سكيلر {new Date().getFullYear()}</p>
        </div>
      </footer>
    </div>
  );
};

export default Courses;
