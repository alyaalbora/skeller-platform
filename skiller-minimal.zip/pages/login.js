import React, { useState } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import Navbar from '../components/Navbar';
import LoginForm from '../components/LoginForm';

const Login = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();

  const handleLogin = async (userData) => {
    try {
      setLoading(true);
      setError('');
      
      // This would be replaced with actual API call in production
      console.log('Login data:', userData);
      
      // Simulate successful login
      setTimeout(() => {
        // Redirect to home page after successful login
        router.push('/');
      }, 1000);
    } catch (err) {
      setError(err.message || 'حدث خطأ أثناء تسجيل الدخول');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <Head>
        <title>تسجيل الدخول - منصة سكيلر التعليمية</title>
        <meta name="description" content="تسجيل الدخول إلى منصة سكيلر التعليمية" />
      </Head>

      <Navbar />
      
      <main className="container main-content">
        <div className="auth-container">
          <LoginForm onLogin={handleLogin} />
        </div>
      </main>
      
      <footer className="footer">
        <div className="container">
          <p>جميع الحقوق محفوظة &copy; منصة سكيلر {new Date().getFullYear()}</p>
        </div>
      </footer>
    </div>
  );
};

export default Login;
