import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import AdminSidebar from '../../../components/admin/AdminSidebar';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  PointElement, 
  LineElement, 
  BarElement,
  Title, 
  Tooltip, 
  Legend,
  ArcElement
} from 'chart.js';
import { Line, Bar, Pie } from 'react-chartjs-2';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

const AdminStats = () => {
  const [statsData, setStatsData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('month'); // 'week', 'month', 'year'
  
  // This would be replaced with actual API call in production
  useEffect(() => {
    // Simulate statistics data
    const mockStatsData = {
      users: {
        total: 1250,
        new: 45,
        growth: 12
      },
      courses: {
        total: 24,
        active: 20,
        categories: {
          'البرمجة': 8,
          'التصميم': 6,
          'التسويق': 4,
          'اللغات': 3,
          'الأعمال': 3
        }
      },
      videos: {
        total: 156,
        views: 8750,
        watchTime: 450000 // in seconds
      },
      dailyViews: [
        { date: '2025-04-01', count: 120 },
        { date: '2025-04-02', count: 145 },
        { date: '2025-04-03', count: 132 },
        { date: '2025-04-04', count: 160 },
        { date: '2025-04-05', count: 178 },
        { date: '2025-04-06', count: 190 },
        { date: '2025-04-07', count: 210 },
        { date: '2025-04-08', count: 235 },
        { date: '2025-04-09', count: 245 },
        { date: '2025-04-10', count: 260 },
        { date: '2025-04-11', count: 285 },
        { date: '2025-04-12', count: 310 },
        { date: '2025-04-13', count: 330 },
        { date: '2025-04-14', count: 350 }
      ],
      topCourses: [
        { title: 'تعلم لغة JavaScript', views: 450 },
        { title: 'أساسيات التصميم الجرافيكي', views: 320 },
        { title: 'التسويق الإلكتروني', views: 280 },
        { title: 'تعلم اللغة الإنجليزية', views: 250 },
        { title: 'إدارة المشاريع', views: 220 }
      ]
    };
    
    setStatsData(mockStatsData);
    setLoading(false);
  }, []);

  const handleTimeRangeChange = (range) => {
    setTimeRange(range);
    // In production, this would fetch new data based on the selected time range
  };

  // Prepare chart data
  const prepareViewsChartData = () => {
    if (!statsData) return null;
    
    const labels = statsData.dailyViews.map(item => {
      const date = new Date(item.date);
      return date.toLocaleDateString('ar-EG', { month: 'short', day: 'numeric' });
    });
    
    const data = statsData.dailyViews.map(item => item.count);
    
    return {
      labels,
      datasets: [
        {
          label: 'عدد المشاهدات',
          data,
          borderColor: '#3f51b5',
          backgroundColor: 'rgba(63, 81, 181, 0.1)',
          tension: 0.4,
          fill: true
        }
      ]
    };
  };

  const prepareCategoriesChartData = () => {
    if (!statsData) return null;
    
    const labels = Object.keys(statsData.courses.categories);
    const data = Object.values(statsData.courses.categories);
    
    return {
      labels,
      datasets: [
        {
          label: 'عدد الكورسات',
          data,
          backgroundColor: [
            'rgba(255, 99, 132, 0.7)',
            'rgba(54, 162, 235, 0.7)',
            'rgba(255, 206, 86, 0.7)',
            'rgba(75, 192, 192, 0.7)',
            'rgba(153, 102, 255, 0.7)'
          ],
          borderWidth: 1
        }
      ]
    };
  };

  const prepareTopCoursesChartData = () => {
    if (!statsData) return null;
    
    const labels = statsData.topCourses.map(course => course.title);
    const data = statsData.topCourses.map(course => course.views);
    
    return {
      labels,
      datasets: [
        {
          label: 'عدد المشاهدات',
          data,
          backgroundColor: 'rgba(63, 81, 181, 0.7)',
          borderColor: 'rgba(63, 81, 181, 1)',
          borderWidth: 1
        }
      ]
    };
  };

  return (
    <div className="admin-layout">
      <Head>
        <title>الإحصائيات - منصة سكيلر التعليمية</title>
        <meta name="description" content="إحصائيات منصة سكيلر التعليمية" />
      </Head>

      <div className="admin-container">
        <AdminSidebar activePage="stats" />
        
        <main className="admin-content">
          <div className="admin-header">
            <h1 className="admin-title">الإحصائيات والتحليلات</h1>
            <div className="time-range-filter">
              <button 
                className={`btn ${timeRange === 'week' ? 'btn-primary' : 'btn-outline'}`}
                onClick={() => handleTimeRangeChange('week')}
              >
                أسبوع
              </button>
              <button 
                className={`btn ${timeRange === 'month' ? 'btn-primary' : 'btn-outline'}`}
                onClick={() => handleTimeRangeChange('month')}
              >
                شهر
              </button>
              <button 
                className={`btn ${timeRange === 'year' ? 'btn-primary' : 'btn-outline'}`}
                onClick={() => handleTimeRangeChange('year')}
              >
                سنة
              </button>
            </div>
          </div>
          
          {loading ? (
            <div className="loading">جاري تحميل الإحصائيات...</div>
          ) : statsData ? (
            <div className="stats-dashboard">
              <div className="stats-overview">
                <div className="stats-card">
                  <div className="stats-icon users-icon">👥</div>
                  <div className="stats-content">
                    <h3>المستخدمين</h3>
                    <div className="stats-numbers">
                      <div className="stats-main-number">{statsData.users.total}</div>
                      <div className="stats-sub-number">+{statsData.users.new} جديد</div>
                    </div>
                    <div className="stats-growth">
                      نمو {statsData.users.growth}% هذا الشهر
                    </div>
                  </div>
                </div>
                
                <div className="stats-card">
                  <div className="stats-icon courses-icon">📚</div>
                  <div className="stats-content">
                    <h3>الكورسات</h3>
                    <div className="stats-numbers">
                      <div className="stats-main-number">{statsData.courses.total}</div>
                      <div className="stats-sub-number">{statsData.courses.active} نشط</div>
                    </div>
                  </div>
                </div>
                
                <div className="stats-card">
                  <div className="stats-icon videos-icon">🎬</div>
                  <div className="stats-content">
                    <h3>الفيديوهات</h3>
                    <div className="stats-numbers">
                      <div className="stats-main-number">{statsData.videos.total}</div>
                      <div className="stats-sub-number">{statsData.videos.views} مشاهدة</div>
                    </div>
                    <div className="stats-watch-time">
                      وقت المشاهدة: {Math.floor(statsData.videos.watchTime / 3600)} ساعة
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="charts-container">
                <div className="chart-card">
                  <h3 className="chart-title">المشاهدات اليومية</h3>
                  <div className="chart-container">
                    {prepareViewsChartData() && (
                      <Line 
                        data={prepareViewsChartData()} 
                        options={{
                          responsive: true,
                          plugins: {
                            legend: {
                              position: 'top',
                            },
                            title: {
                              display: false
                            }
                          }
                        }}
                      />
                    )}
                  </div>
                </div>
                
                <div className="charts-row">
                  <div className="chart-card">
                    <h3 className="chart-title">توزيع الكورسات حسب التصنيف</h3>
                    <div className="chart-container">
                      {prepareCategoriesChartData() && (
                        <Pie 
                          data={prepareCategoriesChartData()} 
                          options={{
                            responsive: true,
                            plugins: {
                              legend: {
                                position: 'right',
                              }
                            }
                          }}
                        />
                      )}
                    </div>
                  </div>
                  
                  <div className="chart-card">
                    <h3 className="chart-title">أكثر الكورسات مشاهدة</h3>
                    <div className="chart-container">
                      {prepareTopCoursesChartData() && (
                        <Bar 
                          data={prepareTopCoursesChartData()} 
                          options={{
                            responsive: true,
                            indexAxis: 'y',
                            plugins: {
                              legend: {
                                display: false
                              }
                            }
                          }}
                        />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="no-data">لا توجد إحصائيات متاحة</div>
          )}
        </main>
      </div>
    </div>
  );
};

export default AdminStats;
