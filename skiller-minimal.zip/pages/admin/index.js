import React from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import AdminSidebar from '../../components/admin/AdminSidebar';

const AdminDashboard = () => {
  const router = useRouter();
  
  // This would be replaced with actual API data in production
  const stats = {
    users: {
      total: 1250,
      new: 45
    },
    courses: {
      total: 24,
      active: 20
    },
    videos: {
      total: 156,
      views: 8750
    },
    revenue: {
      total: 15000,
      monthly: 2500
    }
  };

  return (
    <div className="admin-layout">
      <Head>
        <title>لوحة التحكم - منصة سكيلر التعليمية</title>
        <meta name="description" content="لوحة تحكم المسؤول لمنصة سكيلر التعليمية" />
      </Head>

      <div className="admin-container">
        <AdminSidebar activePage="dashboard" />
        
        <main className="admin-content">
          <div className="admin-header">
            <h1 className="admin-title">لوحة التحكم</h1>
            <div className="admin-actions">
              <button className="btn btn-primary" onClick={() => router.push('/admin/courses/new')}>
                إضافة كورس جديد
              </button>
              <button className="btn btn-secondary" onClick={() => router.push('/admin/videos/new')}>
                إضافة فيديو جديد
              </button>
            </div>
          </div>
          
          <div className="stats-overview">
            <div className="stats-card">
              <div className="stats-icon users-icon">👥</div>
              <div className="stats-content">
                <h3>المستخدمين</h3>
                <div className="stats-numbers">
                  <div className="stats-main-number">{stats.users.total}</div>
                  <div className="stats-sub-number">+{stats.users.new} جديد</div>
                </div>
              </div>
            </div>
            
            <div className="stats-card">
              <div className="stats-icon courses-icon">📚</div>
              <div className="stats-content">
                <h3>الكورسات</h3>
                <div className="stats-numbers">
                  <div className="stats-main-number">{stats.courses.total}</div>
                  <div className="stats-sub-number">{stats.courses.active} نشط</div>
                </div>
              </div>
            </div>
            
            <div className="stats-card">
              <div className="stats-icon videos-icon">🎬</div>
              <div className="stats-content">
                <h3>الفيديوهات</h3>
                <div className="stats-numbers">
                  <div className="stats-main-number">{stats.videos.total}</div>
                  <div className="stats-sub-number">{stats.videos.views} مشاهدة</div>
                </div>
              </div>
            </div>
            
            <div className="stats-card">
              <div className="stats-icon revenue-icon">💰</div>
              <div className="stats-content">
                <h3>الإيرادات</h3>
                <div className="stats-numbers">
                  <div className="stats-main-number">${stats.revenue.total}</div>
                  <div className="stats-sub-number">${stats.revenue.monthly}/شهر</div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="recent-activity">
            <h2 className="section-title">النشاط الأخير</h2>
            <div className="activity-list">
              <div className="activity-item">
                <div className="activity-icon">👤</div>
                <div className="activity-content">
                  <p className="activity-text">قام <strong>أحمد محمد</strong> بالتسجيل في المنصة</p>
                  <p className="activity-time">منذ 5 دقائق</p>
                </div>
              </div>
              
              <div className="activity-item">
                <div className="activity-icon">📺</div>
                <div className="activity-content">
                  <p className="activity-text">تمت إضافة فيديو جديد <strong>مقدمة في البرمجة</strong></p>
                  <p className="activity-time">منذ 2 ساعة</p>
                </div>
              </div>
              
              <div className="activity-item">
                <div className="activity-icon">📚</div>
                <div className="activity-content">
                  <p className="activity-text">تم إنشاء كورس جديد <strong>تعلم لغة JavaScript</strong></p>
                  <p className="activity-time">منذ 1 يوم</p>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;
