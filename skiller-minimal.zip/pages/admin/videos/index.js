import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import AdminSidebar from '../../../components/admin/AdminSidebar';
import { FaEdit, FaTrash, FaEye } from 'react-icons/fa';

const AdminVideos = () => {
  const router = useRouter();
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // This would be replaced with actual API call in production
  useEffect(() => {
    // Simulate videos data
    const mockVideos = [
      {
        _id: 'v1',
        title: 'مقدمة في JavaScript',
        course: {
          _id: 'c1',
          title: 'تعلم لغة JavaScript'
        },
        duration: 600, // 10 minutes in seconds
        views: 120,
        isPublished: true,
        createdAt: '2025-03-15'
      },
      {
        _id: 'v2',
        title: 'المتغيرات والثوابت',
        course: {
          _id: 'c1',
          title: 'تعلم لغة JavaScript'
        },
        duration: 900, // 15 minutes in seconds
        views: 95,
        isPublished: true,
        createdAt: '2025-03-16'
      },
      {
        _id: 'v3',
        title: 'أساسيات التصميم',
        course: {
          _id: 'c2',
          title: 'أساسيات التصميم الجرافيكي'
        },
        duration: 1200, // 20 minutes in seconds
        views: 85,
        isPublished: false,
        createdAt: '2025-03-20'
      }
    ];
    
    setVideos(mockVideos);
    setLoading(false);
  }, []);

  const handleAddVideo = () => {
    router.push('/admin/videos/new');
  };

  const handleEditVideo = (id) => {
    router.push(`/admin/videos/edit/${id}`);
  };

  const handleDeleteVideo = (id) => {
    // This would be replaced with actual API call in production
    if (window.confirm('هل أنت متأكد من حذف هذا الفيديو؟')) {
      setVideos(videos.filter(video => video._id !== id));
    }
  };

  const handleViewVideo = (courseId, videoId) => {
    router.push(`/courses/${courseId}?video=${videoId}`);
  };

  const formatDuration = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="admin-layout">
      <Head>
        <title>إدارة الفيديوهات - منصة سكيلر التعليمية</title>
        <meta name="description" content="إدارة الفيديوهات في منصة سكيلر التعليمية" />
      </Head>

      <div className="admin-container">
        <AdminSidebar activePage="videos" />
        
        <main className="admin-content">
          <div className="admin-header">
            <h1 className="admin-title">إدارة الفيديوهات</h1>
            <div className="admin-actions">
              <button className="btn btn-primary" onClick={handleAddVideo}>
                إضافة فيديو جديد
              </button>
            </div>
          </div>
          
          {loading ? (
            <div className="loading">جاري تحميل الفيديوهات...</div>
          ) : (
            <div className="admin-table-container">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>عنوان الفيديو</th>
                    <th>الكورس</th>
                    <th>المدة</th>
                    <th>المشاهدات</th>
                    <th>الحالة</th>
                    <th>تاريخ الإضافة</th>
                    <th>الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {videos.map((video) => (
                    <tr key={video._id}>
                      <td>{video.title}</td>
                      <td>{video.course.title}</td>
                      <td>{formatDuration(video.duration)}</td>
                      <td>{video.views}</td>
                      <td>
                        <span className={`status-badge ${video.isPublished ? 'status-active' : 'status-draft'}`}>
                          {video.isPublished ? 'منشور' : 'مسودة'}
                        </span>
                      </td>
                      <td>{new Date(video.createdAt).toLocaleDateString('ar-EG')}</td>
                      <td className="actions-cell">
                        <button 
                          className="action-btn view-btn" 
                          onClick={() => handleViewVideo(video.course._id, video._id)}
                          title="عرض الفيديو"
                        >
                          <FaEye />
                        </button>
                        <button 
                          className="action-btn edit-btn" 
                          onClick={() => handleEditVideo(video._id)}
                          title="تعديل الفيديو"
                        >
                          <FaEdit />
                        </button>
                        <button 
                          className="action-btn delete-btn" 
                          onClick={() => handleDeleteVideo(video._id)}
                          title="حذف الفيديو"
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default AdminVideos;
