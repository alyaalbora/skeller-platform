import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import AdminSidebar from '../../../components/admin/AdminSidebar';
import { FaEdit, FaTrash, FaEye } from 'react-icons/fa';

const AdminCourses = () => {
  const router = useRouter();
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // This would be replaced with actual API call in production
  useEffect(() => {
    // Simulate courses data
    const mockCourses = [
      {
        _id: 'c1',
        title: 'تعلم لغة JavaScript',
        instructor: 'أحمد محمد',
        category: 'البرمجة',
        duration: 180,
        videos: 12,
        views: 450,
        isPublished: true,
        createdAt: '2025-03-15'
      },
      {
        _id: 'c2',
        title: 'أساسيات التصميم الجرافيكي',
        instructor: 'سارة أحمد',
        category: 'التصميم',
        duration: 240,
        videos: 15,
        views: 320,
        isPublished: true,
        createdAt: '2025-03-10'
      },
      {
        _id: 'c3',
        title: 'التسويق الإلكتروني',
        instructor: 'محمد علي',
        category: 'التسويق',
        duration: 150,
        videos: 10,
        views: 280,
        isPublished: false,
        createdAt: '2025-04-01'
      }
    ];
    
    setCourses(mockCourses);
    setLoading(false);
  }, []);

  const handleAddCourse = () => {
    router.push('/admin/courses/new');
  };

  const handleEditCourse = (id) => {
    router.push(`/admin/courses/edit/${id}`);
  };

  const handleDeleteCourse = (id) => {
    // This would be replaced with actual API call in production
    if (window.confirm('هل أنت متأكد من حذف هذا الكورس؟')) {
      setCourses(courses.filter(course => course._id !== id));
    }
  };

  const handleViewCourse = (id) => {
    router.push(`/courses/${id}`);
  };

  return (
    <div className="admin-layout">
      <Head>
        <title>إدارة الكورسات - منصة سكيلر التعليمية</title>
        <meta name="description" content="إدارة الكورسات في منصة سكيلر التعليمية" />
      </Head>

      <div className="admin-container">
        <AdminSidebar activePage="courses" />
        
        <main className="admin-content">
          <div className="admin-header">
            <h1 className="admin-title">إدارة الكورسات</h1>
            <div className="admin-actions">
              <button className="btn btn-primary" onClick={handleAddCourse}>
                إضافة كورس جديد
              </button>
            </div>
          </div>
          
          {loading ? (
            <div className="loading">جاري تحميل الكورسات...</div>
          ) : (
            <div className="admin-table-container">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>عنوان الكورس</th>
                    <th>المدرب</th>
                    <th>التصنيف</th>
                    <th>المدة</th>
                    <th>الفيديوهات</th>
                    <th>المشاهدات</th>
                    <th>الحالة</th>
                    <th>تاريخ الإنشاء</th>
                    <th>الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {courses.map((course) => (
                    <tr key={course._id}>
                      <td>{course.title}</td>
                      <td>{course.instructor}</td>
                      <td>{course.category}</td>
                      <td>{Math.floor(course.duration / 60)} ساعة {course.duration % 60} دقيقة</td>
                      <td>{course.videos}</td>
                      <td>{course.views}</td>
                      <td>
                        <span className={`status-badge ${course.isPublished ? 'status-active' : 'status-draft'}`}>
                          {course.isPublished ? 'منشور' : 'مسودة'}
                        </span>
                      </td>
                      <td>{new Date(course.createdAt).toLocaleDateString('ar-EG')}</td>
                      <td className="actions-cell">
                        <button 
                          className="action-btn view-btn" 
                          onClick={() => handleViewCourse(course._id)}
                          title="عرض الكورس"
                        >
                          <FaEye />
                        </button>
                        <button 
                          className="action-btn edit-btn" 
                          onClick={() => handleEditCourse(course._id)}
                          title="تعديل الكورس"
                        >
                          <FaEdit />
                        </button>
                        <button 
                          className="action-btn delete-btn" 
                          onClick={() => handleDeleteCourse(course._id)}
                          title="حذف الكورس"
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default AdminCourses;
