import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import AdminSidebar from '../../../components/admin/AdminSidebar';
import { FaEdit, FaTrash, FaUserShield, FaUserLock } from 'react-icons/fa';

const AdminUsers = () => {
  const router = useRouter();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // This would be replaced with actual API call in production
  useEffect(() => {
    // Simulate users data
    const mockUsers = [
      {
        _id: 'u1',
        username: 'ahmed_mohamed',
        email: 'ahmed@example.com',
        role: 'user',
        createdAt: '2025-02-10',
        lastLogin: '2025-04-12'
      },
      {
        _id: 'u2',
        username: 'sara_ahmed',
        email: 'sara@example.com',
        role: 'user',
        createdAt: '2025-03-05',
        lastLogin: '2025-04-13'
      },
      {
        _id: 'u3',
        username: 'admin_user',
        email: 'admin@example.com',
        role: 'admin',
        createdAt: '2025-01-15',
        lastLogin: '2025-04-14'
      }
    ];
    
    setUsers(mockUsers);
    setLoading(false);
  }, []);

  const handleEditUser = (id) => {
    router.push(`/admin/users/edit/${id}`);
  };

  const handleDeleteUser = (id) => {
    // This would be replaced with actual API call in production
    if (window.confirm('هل أنت متأكد من حذف هذا المستخدم؟')) {
      setUsers(users.filter(user => user._id !== id));
    }
  };

  const handleMakeAdmin = (id) => {
    // This would be replaced with actual API call in production
    if (window.confirm('هل أنت متأكد من ترقية هذا المستخدم إلى مسؤول؟')) {
      setUsers(users.map(user => 
        user._id === id ? { ...user, role: 'admin' } : user
      ));
    }
  };

  const handleRemoveAdmin = (id) => {
    // This would be replaced with actual API call in production
    if (window.confirm('هل أنت متأكد من إزالة صلاحيات المسؤول من هذا المستخدم؟')) {
      setUsers(users.map(user => 
        user._id === id ? { ...user, role: 'user' } : user
      ));
    }
  };

  return (
    <div className="admin-layout">
      <Head>
        <title>إدارة المستخدمين - منصة سكيلر التعليمية</title>
        <meta name="description" content="إدارة المستخدمين في منصة سكيلر التعليمية" />
      </Head>

      <div className="admin-container">
        <AdminSidebar activePage="users" />
        
        <main className="admin-content">
          <div className="admin-header">
            <h1 className="admin-title">إدارة المستخدمين</h1>
          </div>
          
          {loading ? (
            <div className="loading">جاري تحميل المستخدمين...</div>
          ) : (
            <div className="admin-table-container">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>اسم المستخدم</th>
                    <th>البريد الإلكتروني</th>
                    <th>الدور</th>
                    <th>تاريخ التسجيل</th>
                    <th>آخر تسجيل دخول</th>
                    <th>الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user._id}>
                      <td>{user.username}</td>
                      <td>{user.email}</td>
                      <td>
                        <span className={`role-badge ${user.role === 'admin' ? 'role-admin' : 'role-user'}`}>
                          {user.role === 'admin' ? 'مسؤول' : 'مستخدم'}
                        </span>
                      </td>
                      <td>{new Date(user.createdAt).toLocaleDateString('ar-EG')}</td>
                      <td>{new Date(user.lastLogin).toLocaleDateString('ar-EG')}</td>
                      <td className="actions-cell">
                        <button 
                          className="action-btn edit-btn" 
                          onClick={() => handleEditUser(user._id)}
                          title="تعديل المستخدم"
                        >
                          <FaEdit />
                        </button>
                        {user.role === 'user' ? (
                          <button 
                            className="action-btn admin-btn" 
                            onClick={() => handleMakeAdmin(user._id)}
                            title="ترقية إلى مسؤول"
                          >
                            <FaUserShield />
                          </button>
                        ) : (
                          <button 
                            className="action-btn remove-admin-btn" 
                            onClick={() => handleRemoveAdmin(user._id)}
                            title="إزالة صلاحيات المسؤول"
                          >
                            <FaUserLock />
                          </button>
                        )}
                        <button 
                          className="action-btn delete-btn" 
                          onClick={() => handleDeleteUser(user._id)}
                          title="حذف المستخدم"
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default AdminUsers;
