const mongoose = require('mongoose');

const statSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: ['visit', 'view', 'signup', 'login'],
    required: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  course: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Course'
  },
  video: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Video'
  },
  ip: {
    type: String
  },
  userAgent: {
    type: String
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

const Stat = mongoose.model('Stat', statSchema);

module.exports = Stat;
