const express = require('express');
const router = express.Router();
const videoController = require('../controllers/videoController');
const { protect, admin } = require('../middleware/auth');

// Public routes
router.get('/', videoController.getVideos);
router.get('/:id', videoController.getVideoById);

// Protected routes
router.post('/', protect, admin, videoController.uploadVideo);
router.put('/:id', protect, videoController.updateVideo);
router.delete('/:id', protect, videoController.deleteVideo);

module.exports = router;
