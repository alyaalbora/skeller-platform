const express = require('express');
const router = express.Router();
const statController = require('../controllers/statController');
const { protect, admin } = require('../middleware/auth');

// Public routes
router.post('/course/:id', statController.trackCourseView);
router.post('/video/:id', statController.trackVideoView);

// Protected routes
router.get('/', protect, admin, statController.getStats);

module.exports = router;
