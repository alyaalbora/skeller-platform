const express = require('express');
const router = express.Router();
const courseController = require('../controllers/courseController');
const { protect, admin } = require('../middleware/auth');

// Public routes
router.get('/', courseController.getCourses);
router.get('/:id', courseController.getCourseById);

// Protected routes
router.post('/', protect, admin, courseController.createCourse);
router.put('/:id', protect, courseController.updateCourse);
router.delete('/:id', protect, courseController.deleteCourse);

module.exports = router;
