import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { FaHome, FaBook, FaUser, FaSearch } from 'react-icons/fa';

const Navbar = ({ user }) => {
  const router = useRouter();
  
  return (
    <nav className="navbar">
      <div className="container navbar-container">
        <Link href="/">
          <div className="navbar-brand">
            <h1>سكيلر</h1>
          </div>
        </Link>
        
        <div className="navbar-search">
          <div className="search-box">
            <input 
              type="text" 
              placeholder="ابحث عن كورسات..." 
              className="search-input"
            />
            <button className="search-button">
              <FaSearch />
            </button>
          </div>
        </div>
        
        <div className="navbar-menu">
          <Link href="/">
            <div className={`navbar-item ${router.pathname === '/' ? 'active' : ''}`}>
              <FaHome />
              <span>الرئيسية</span>
            </div>
          </Link>
          
          <Link href="/courses">
            <div className={`navbar-item ${router.pathname.startsWith('/courses') ? 'active' : ''}`}>
              <FaBook />
              <span>الكورسات</span>
            </div>
          </Link>
          
          {user ? (
            <Link href="/profile">
              <div className={`navbar-item ${router.pathname.startsWith('/profile') ? 'active' : ''}`}>
                <FaUser />
                <span>حسابي</span>
              </div>
            </Link>
          ) : (
            <Link href="/login">
              <div className={`navbar-item ${router.pathname === '/login' ? 'active' : ''}`}>
                <FaUser />
                <span>تسجيل الدخول</span>
              </div>
            </Link>
          )}
          
          {user && user.role === 'admin' && (
            <Link href="/admin">
              <div className={`navbar-item ${router.pathname.startsWith('/admin') ? 'active' : ''}`}>
                <span>لوحة التحكم</span>
              </div>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
