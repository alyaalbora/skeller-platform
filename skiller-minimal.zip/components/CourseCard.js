import React from 'react';
import Link from 'next/link';

const CourseCard = ({ course }) => {
  return (
    <div className="course-card card">
      <div className="course-thumbnail">
        <img 
          src={course.thumbnail || '/images/default-course.jpg'} 
          alt={course.title}
        />
      </div>
      <div className="course-content">
        <h3 className="course-title">{course.title}</h3>
        <p className="course-instructor">المدرب: {course.instructor}</p>
        <div className="course-meta">
          <span className="course-duration">{Math.floor(course.duration / 60)} ساعة {course.duration % 60} دقيقة</span>
          <span className="course-videos">{course.videos?.length || 0} فيديو</span>
        </div>
        <p className="course-description">{course.description.substring(0, 100)}...</p>
        <Link href={`/courses/${course._id}`}>
          <button className="btn btn-primary">عرض الكورس</button>
        </Link>
      </div>
    </div>
  );
};

export default CourseCard;
