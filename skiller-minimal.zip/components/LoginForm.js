import React, { useState } from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import Link from 'next/link';

const LoginForm = ({ onLogin }) => {
  const [error, setError] = useState('');
  
  const formik = useFormik({
    initialValues: {
      email: '',
      password: ''
    },
    validationSchema: Yup.object({
      email: Yup.string()
        .email('بريد إلكتروني غير صالح')
        .required('البريد الإلكتروني مطلوب'),
      password: Yup.string()
        .min(6, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل')
        .required('كلمة المرور مطلوبة')
    }),
    onSubmit: async (values) => {
      try {
        setError('');
        // This will be replaced with actual API call
        if (onLogin) {
          onLogin(values);
        }
      } catch (err) {
        setError(err.response?.data?.message || 'حدث خطأ أثناء تسجيل الدخول');
      }
    }
  });
  
  return (
    <div className="auth-form card">
      <h2 className="auth-title">تسجيل الدخول</h2>
      
      {error && <div className="alert alert-error">{error}</div>}
      
      <form onSubmit={formik.handleSubmit}>
        <div className="form-group">
          <label htmlFor="email">البريد الإلكتروني</label>
          <input
            id="email"
            name="email"
            type="email"
            className="form-control"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.email}
          />
          {formik.touched.email && formik.errors.email ? (
            <div className="error-message">{formik.errors.email}</div>
          ) : null}
        </div>
        
        <div className="form-group">
          <label htmlFor="password">كلمة المرور</label>
          <input
            id="password"
            name="password"
            type="password"
            className="form-control"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.password}
          />
          {formik.touched.password && formik.errors.password ? (
            <div className="error-message">{formik.errors.password}</div>
          ) : null}
        </div>
        
        <button type="submit" className="btn btn-primary btn-block" disabled={formik.isSubmitting}>
          {formik.isSubmitting ? 'جاري التسجيل...' : 'تسجيل الدخول'}
        </button>
      </form>
      
      <div className="auth-links">
        <p>
          ليس لديك حساب؟ <Link href="/register">إنشاء حساب جديد</Link>
        </p>
      </div>
    </div>
  );
};

export default LoginForm;
