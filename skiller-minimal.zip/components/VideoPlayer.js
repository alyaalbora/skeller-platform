import React from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';

const VideoPlayer = ({ video }) => {
  return (
    <div className="video-player">
      <div className="video-container">
        <video 
          controls 
          src={video?.filePath} 
          poster={video?.thumbnail || '/images/default-video.jpg'}
          className="video-element"
        >
          متصفحك لا يدعم تشغيل الفيديو
        </video>
      </div>
      <div className="video-info">
        <h2 className="video-title">{video?.title}</h2>
        <div className="video-meta">
          <span className="video-views">{video?.views} مشاهدة</span>
          <span className="video-duration">{Math.floor(video?.duration / 60)}:{String(video?.duration % 60).padStart(2, '0')}</span>
        </div>
        <p className="video-description">{video?.description}</p>
      </div>
    </div>
  );
};

export default VideoPlayer;
