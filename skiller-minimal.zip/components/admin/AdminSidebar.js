import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { FaHome, FaBook, FaVideo, FaUsers, FaChartBar, FaCog } from 'react-icons/fa';

const AdminSidebar = ({ activePage }) => {
  const router = useRouter();
  
  return (
    <div className="admin-sidebar">
      <div className="admin-sidebar-header">
        <h2>لوحة التحكم</h2>
      </div>
      <ul className="admin-menu">
        <li className={activePage === 'dashboard' ? 'active' : ''}>
          <Link href="/admin">
            <div className="admin-menu-item">
              <FaHome />
              <span>الرئيسية</span>
            </div>
          </Link>
        </li>
        <li className={activePage === 'courses' ? 'active' : ''}>
          <Link href="/admin/courses">
            <div className="admin-menu-item">
              <FaBook />
              <span>إدارة الكورسات</span>
            </div>
          </Link>
        </li>
        <li className={activePage === 'videos' ? 'active' : ''}>
          <Link href="/admin/videos">
            <div className="admin-menu-item">
              <FaVideo />
              <span>إدارة الفيديوهات</span>
            </div>
          </Link>
        </li>
        <li className={activePage === 'users' ? 'active' : ''}>
          <Link href="/admin/users">
            <div className="admin-menu-item">
              <FaUsers />
              <span>إدارة المستخدمين</span>
            </div>
          </Link>
        </li>
        <li className={activePage === 'stats' ? 'active' : ''}>
          <Link href="/admin/stats">
            <div className="admin-menu-item">
              <FaChartBar />
              <span>الإحصائيات</span>
            </div>
          </Link>
        </li>
        <li className={activePage === 'settings' ? 'active' : ''}>
          <Link href="/admin/settings">
            <div className="admin-menu-item">
              <FaCog />
              <span>الإعدادات</span>
            </div>
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default AdminSidebar;
