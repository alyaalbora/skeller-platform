import React, { useState } from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import Link from 'next/link';

const RegisterForm = ({ onRegister }) => {
  const [error, setError] = useState('');
  
  const formik = useFormik({
    initialValues: {
      username: '',
      email: '',
      password: '',
      confirmPassword: ''
    },
    validationSchema: Yup.object({
      username: Yup.string()
        .min(3, 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل')
        .required('اسم المستخدم مطلوب'),
      email: Yup.string()
        .email('بريد إلكتروني غير صالح')
        .required('البريد الإلكتروني مطلوب'),
      password: Yup.string()
        .min(6, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل')
        .required('كلمة المرور مطلوبة'),
      confirmPassword: Yup.string()
        .oneOf([Yup.ref('password'), null], 'كلمات المرور غير متطابقة')
        .required('تأكيد كلمة المرور مطلوب')
    }),
    onSubmit: async (values) => {
      try {
        setError('');
        // This will be replaced with actual API call
        if (onRegister) {
          onRegister(values);
        }
      } catch (err) {
        setError(err.response?.data?.message || 'حدث خطأ أثناء إنشاء الحساب');
      }
    }
  });
  
  return (
    <div className="auth-form card">
      <h2 className="auth-title">إنشاء حساب جديد</h2>
      
      {error && <div className="alert alert-error">{error}</div>}
      
      <form onSubmit={formik.handleSubmit}>
        <div className="form-group">
          <label htmlFor="username">اسم المستخدم</label>
          <input
            id="username"
            name="username"
            type="text"
            className="form-control"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.username}
          />
          {formik.touched.username && formik.errors.username ? (
            <div className="error-message">{formik.errors.username}</div>
          ) : null}
        </div>
        
        <div className="form-group">
          <label htmlFor="email">البريد الإلكتروني</label>
          <input
            id="email"
            name="email"
            type="email"
            className="form-control"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.email}
          />
          {formik.touched.email && formik.errors.email ? (
            <div className="error-message">{formik.errors.email}</div>
          ) : null}
        </div>
        
        <div className="form-group">
          <label htmlFor="password">كلمة المرور</label>
          <input
            id="password"
            name="password"
            type="password"
            className="form-control"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.password}
          />
          {formik.touched.password && formik.errors.password ? (
            <div className="error-message">{formik.errors.password}</div>
          ) : null}
        </div>
        
        <div className="form-group">
          <label htmlFor="confirmPassword">تأكيد كلمة المرور</label>
          <input
            id="confirmPassword"
            name="confirmPassword"
            type="password"
            className="form-control"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.confirmPassword}
          />
          {formik.touched.confirmPassword && formik.errors.confirmPassword ? (
            <div className="error-message">{formik.errors.confirmPassword}</div>
          ) : null}
        </div>
        
        <button type="submit" className="btn btn-primary btn-block" disabled={formik.isSubmitting}>
          {formik.isSubmitting ? 'جاري التسجيل...' : 'إنشاء حساب'}
        </button>
      </form>
      
      <div className="auth-links">
        <p>
          لديك حساب بالفعل؟ <Link href="/login">تسجيل الدخول</Link>
        </p>
      </div>
    </div>
  );
};

export default RegisterForm;
