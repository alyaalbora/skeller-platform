const Stat = require('../models/Stat');
const User = require('../models/User');
const Course = require('../models/Course');
const Video = require('../models/Video');

// Middleware to track page visits
exports.trackVisit = async (req, res, next) => {
  try {
    const stat = new Stat({
      type: 'visit',
      user: req.user ? req.user._id : null,
      ip: req.ip,
      userAgent: req.headers['user-agent']
    });
    
    await stat.save();
    next();
  } catch (error) {
    console.error('Error tracking visit:', error);
    next(); // Continue even if tracking fails
  }
};

// @desc    Track course view
// @route   POST /api/stats/course/:id
// @access  Public
exports.trackCourseView = async (req, res) => {
  try {
    const courseId = req.params.id;
    
    // Verify course exists
    const course = await Course.findById(courseId);
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'الكورس غير موجود'
      });
    }
    
    // Create stat record
    const stat = new Stat({
      type: 'view',
      user: req.user ? req.user._id : null,
      course: courseId,
      ip: req.ip,
      userAgent: req.headers['user-agent']
    });
    
    await stat.save();
    
    // Increment course views
    course.views += 1;
    await course.save();
    
    res.status(200).json({
      success: true,
      message: 'تم تسجيل المشاهدة بنجاح'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في تسجيل المشاهدة',
      error: error.message
    });
  }
};

// @desc    Track video view
// @route   POST /api/stats/video/:id
// @access  Public
exports.trackVideoView = async (req, res) => {
  try {
    const videoId = req.params.id;
    
    // Verify video exists
    const video = await Video.findById(videoId);
    if (!video) {
      return res.status(404).json({
        success: false,
        message: 'الفيديو غير موجود'
      });
    }
    
    // Create stat record
    const stat = new Stat({
      type: 'view',
      user: req.user ? req.user._id : null,
      video: videoId,
      course: video.course,
      ip: req.ip,
      userAgent: req.headers['user-agent']
    });
    
    await stat.save();
    
    // Increment video views
    video.views += 1;
    await video.save();
    
    res.status(200).json({
      success: true,
      message: 'تم تسجيل المشاهدة بنجاح'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في تسجيل المشاهدة',
      error: error.message
    });
  }
};

// @desc    Get platform statistics
// @route   GET /api/stats
// @access  Private/Admin
exports.getStats = async (req, res) => {
  try {
    // Get date range from query params or default to last 30 days
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - (req.query.days || 30));
    
    // Total users
    const totalUsers = await User.countDocuments();
    
    // New users in date range
    const newUsers = await User.countDocuments({
      createdAt: { $gte: startDate, $lte: endDate }
    });
    
    // Total courses
    const totalCourses = await Course.countDocuments();
    
    // Total videos
    const totalVideos = await Video.countDocuments();
    
    // Total views
    const totalViews = await Stat.countDocuments({ type: 'view' });
    
    // Views in date range
    const periodViews = await Stat.countDocuments({
      type: 'view',
      timestamp: { $gte: startDate, $lte: endDate }
    });
    
    // Daily views for chart
    const dailyViews = await Stat.aggregate([
      {
        $match: {
          type: 'view',
          timestamp: { $gte: startDate, $lte: endDate }
        }
      },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$timestamp' } },
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);
    
    // Top courses by views
    const topCourses = await Course.find()
      .sort({ views: -1 })
      .limit(5)
      .select('title views');
    
    // Top videos by views
    const topVideos = await Video.find()
      .sort({ views: -1 })
      .limit(5)
      .select('title views');
    
    res.status(200).json({
      success: true,
      stats: {
        users: {
          total: totalUsers,
          new: newUsers
        },
        content: {
          courses: totalCourses,
          videos: totalVideos
        },
        views: {
          total: totalViews,
          period: periodViews,
          daily: dailyViews
        },
        top: {
          courses: topCourses,
          videos: topVideos
        }
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب الإحصائيات',
      error: error.message
    });
  }
};
