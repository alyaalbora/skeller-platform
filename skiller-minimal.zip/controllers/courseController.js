const Course = require('../models/Course');
const Video = require('../models/Video');

// @desc    Create a new course
// @route   POST /api/courses
// @access  Private/Admin
exports.createCourse = async (req, res) => {
  try {
    const { title, description, instructor, category } = req.body;
    
    const course = await Course.create({
      title,
      description,
      instructor,
      category,
      createdBy: req.user._id
    });
    
    res.status(201).json({
      success: true,
      course
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في إنشاء الكورس',
      error: error.message
    });
  }
};

// @desc    Get all courses
// @route   GET /api/courses
// @access  Public
exports.getCourses = async (req, res) => {
  try {
    const courses = await Course.find({ isPublished: true })
      .sort({ createdAt: -1 })
      .populate('createdBy', 'username');
    
    res.status(200).json({
      success: true,
      count: courses.length,
      courses
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب الكورسات',
      error: error.message
    });
  }
};

// @desc    Get course by ID
// @route   GET /api/courses/:id
// @access  Public
exports.getCourseById = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id)
      .populate('createdBy', 'username')
      .populate('videos');
    
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'الكورس غير موجود'
      });
    }
    
    // Increment view count
    course.views += 1;
    await course.save();
    
    res.status(200).json({
      success: true,
      course
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب الكورس',
      error: error.message
    });
  }
};

// @desc    Update course
// @route   PUT /api/courses/:id
// @access  Private/Admin
exports.updateCourse = async (req, res) => {
  try {
    let course = await Course.findById(req.params.id);
    
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'الكورس غير موجود'
      });
    }
    
    // Check if user is the course creator or admin
    if (course.createdBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'غير مصرح بتعديل هذا الكورس'
      });
    }
    
    course = await Course.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });
    
    res.status(200).json({
      success: true,
      course
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في تحديث الكورس',
      error: error.message
    });
  }
};

// @desc    Delete course
// @route   DELETE /api/courses/:id
// @access  Private/Admin
exports.deleteCourse = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'الكورس غير موجود'
      });
    }
    
    // Check if user is the course creator or admin
    if (course.createdBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'غير مصرح بحذف هذا الكورس'
      });
    }
    
    // Delete all videos associated with this course
    await Video.deleteMany({ course: req.params.id });
    
    // Delete the course
    await course.remove();
    
    res.status(200).json({
      success: true,
      message: 'تم حذف الكورس وجميع الفيديوهات المرتبطة به بنجاح'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في حذف الكورس',
      error: error.message
    });
  }
};
