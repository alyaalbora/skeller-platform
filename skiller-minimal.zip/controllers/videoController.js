const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Video = require('../models/Video');
const Course = require('../models/Course');

// Configure multer storage
const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    const uploadPath = path.join(__dirname, '../../uploads/videos');
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    
    cb(null, uploadPath);
  },
  filename: function(req, file, cb) {
    // Create unique filename with timestamp and original extension
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, 'video-' + uniqueSuffix + ext);
  }
});

// File filter to accept only video files
const fileFilter = (req, file, cb) => {
  const allowedTypes = /mp4|mov|avi|wmv|mkv|webm/;
  const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = allowedTypes.test(file.mimetype);
  
  if (extname && mimetype) {
    return cb(null, true);
  } else {
    cb(new Error('فقط ملفات الفيديو مسموح بها'));
  }
};

// Configure upload with file size limit (1GB)
const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: process.env.MAX_FILE_SIZE || 1024 * 1024 * 1024 } // 1GB
});

// @desc    Upload video
// @route   POST /api/videos
// @access  Private/Admin
exports.uploadVideo = async (req, res) => {
  try {
    // Use multer upload middleware
    upload.single('video')(req, res, async function(err) {
      if (err) {
        return res.status(400).json({
          success: false,
          message: err.message
        });
      }
      
      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: 'يرجى تحميل ملف فيديو'
        });
      }
      
      const { title, description, courseId, duration, order } = req.body;
      
      // Check if course exists
      const course = await Course.findById(courseId);
      if (!course) {
        // Remove uploaded file if course doesn't exist
        fs.unlinkSync(req.file.path);
        
        return res.status(404).json({
          success: false,
          message: 'الكورس غير موجود'
        });
      }
      
      // Create video record
      const video = await Video.create({
        title,
        description,
        filePath: '/uploads/videos/' + req.file.filename,
        duration,
        course: courseId,
        order: order || 0,
        createdBy: req.user._id
      });
      
      // Add video to course
      course.videos.push(video._id);
      
      // Update course duration
      course.duration = course.duration + parseInt(duration);
      await course.save();
      
      res.status(201).json({
        success: true,
        video
      });
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في رفع الفيديو',
      error: error.message
    });
  }
};

// @desc    Get all videos
// @route   GET /api/videos
// @access  Public
exports.getVideos = async (req, res) => {
  try {
    const videos = await Video.find({ isPublished: true })
      .sort({ createdAt: -1 })
      .populate('course', 'title')
      .populate('createdBy', 'username');
    
    res.status(200).json({
      success: true,
      count: videos.length,
      videos
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب الفيديوهات',
      error: error.message
    });
  }
};

// @desc    Get video by ID
// @route   GET /api/videos/:id
// @access  Public
exports.getVideoById = async (req, res) => {
  try {
    const video = await Video.findById(req.params.id)
      .populate('course', 'title')
      .populate('createdBy', 'username');
    
    if (!video) {
      return res.status(404).json({
        success: false,
        message: 'الفيديو غير موجود'
      });
    }
    
    // Increment view count
    video.views += 1;
    await video.save();
    
    res.status(200).json({
      success: true,
      video
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في جلب الفيديو',
      error: error.message
    });
  }
};

// @desc    Update video
// @route   PUT /api/videos/:id
// @access  Private/Admin
exports.updateVideo = async (req, res) => {
  try {
    let video = await Video.findById(req.params.id);
    
    if (!video) {
      return res.status(404).json({
        success: false,
        message: 'الفيديو غير موجود'
      });
    }
    
    // Check if user is the video creator or admin
    if (video.createdBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'غير مصرح بتعديل هذا الفيديو'
      });
    }
    
    video = await Video.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });
    
    res.status(200).json({
      success: true,
      video
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في تحديث الفيديو',
      error: error.message
    });
  }
};

// @desc    Delete video
// @route   DELETE /api/videos/:id
// @access  Private/Admin
exports.deleteVideo = async (req, res) => {
  try {
    const video = await Video.findById(req.params.id);
    
    if (!video) {
      return res.status(404).json({
        success: false,
        message: 'الفيديو غير موجود'
      });
    }
    
    // Check if user is the video creator or admin
    if (video.createdBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'غير مصرح بحذف هذا الفيديو'
      });
    }
    
    // Delete video file from filesystem
    const filePath = path.join(__dirname, '../..', video.filePath);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    
    // Update course (remove video from course and update duration)
    const course = await Course.findById(video.course);
    if (course) {
      course.videos = course.videos.filter(v => v.toString() !== video._id.toString());
      course.duration = Math.max(0, course.duration - video.duration);
      await course.save();
    }
    
    // Delete video from database
    await video.remove();
    
    res.status(200).json({
      success: true,
      message: 'تم حذف الفيديو بنجاح'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'خطأ في حذف الفيديو',
      error: error.message
    });
  }
};
